#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<errno.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
int main(int argc, char** argv)   //客户端
{
    if(argc!=2)   
        return 0;
    int sockfd;
    char buff[1000]={0};
    struct sockaddr_in servaddr;
    sockfd=socket(AF_INET,SOCK_STREAM,0);
    servaddr.sin_family = AF_INET;   //iv4协议
    servaddr.sin_port = htons(8000);  //8000端口
    inet_pton(AF_INET, argv[1], &servaddr.sin_addr);  //指定IP地址  
    if( connect(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr)) < 0)  //链接服务器  
    {
        printf("connect error: %s(errno: %d)\n",strerror(errno),errno);
        return 0;
    }
    while(1)
    {
        printf("Enter:");      
        fgets(buff,998,stdin);
        send(sockfd,buff,strlen(buff),0);
    }