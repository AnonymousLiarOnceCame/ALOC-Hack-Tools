#include<stdio.h>
#include<string.h>
#include<sys/types.h>
#include<error.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<signal.h>
#include<sys/wait.h>
void handle()
{
    while(waitpid(-1,NULL,WNOHANG));  //处理完当前所有的僵尸进程
}
int main()       //服务端
{
    int socket_fd,connect_fd;
    char buff[1000]={0};
    struct sockaddr_in servaddr;
    socket_fd=socket(AF_INET,SOCK_STREAM,0);
    servaddr.sin_family=AF_INET;
    servaddr.sin_addr.s_addr=htonl(INADDR_ANY);
    servaddr.sin_port=htons(8000);
    if ( bind(socket_fd,(struct sockaddr*)&servaddr,sizeof(servaddr) )==-1)
    { 
       printf("bind error!\n");
       return 0;
    }
    listen(socket_fd,10);
    while(1)
    {
        connect_fd=accept(socket_fd,NULL,NULL);
        if(!fork())   //每接受一个客户端开一个子进程
        {
            while(1)
            {
                if(recv(connect_fd,buff,999,0)==0)
                    return 0;
                printf("get:%s",buff);
            }
        }
        signal(SIGCHLD,handle);  //当子进程结束时，运行handle函数
    }
    return 0;
}