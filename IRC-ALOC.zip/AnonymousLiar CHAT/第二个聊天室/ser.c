#include<stdio.h>  
#include<stdlib.h>  
#include<string.h>  
#include<errno.h>  
#include<sys/types.h>  
#include<sys/socket.h>  
#include<netinet/in.h>  
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>

typedef struct userinfo
{
    char id[20];
    char codes[20];
    char name[20];
    struct userinfo *next;
    int friendnum;
    int state;
    char friend[100][2][20];
}user;
user *head,*tail,nowuser,usenull;
#include"ser2.h"
int main(int argc, char** argv)  
{  
    int    socket_fd, connect_fd;  
    struct sockaddr_in     servaddr;  
    char    buff[4096];  
    if( (socket_fd = socket(AF_INET, SOCK_STREAM, 0)) == -1 )
    {  
      printf("create socket error: %s(errno: %d)\n",strerror(errno),errno);  
      exit(0);  
    }  
    memset(&servaddr, 0, sizeof(servaddr));  
    servaddr.sin_family = AF_INET;  
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);  
    servaddr.sin_port = htons(8000);  
    if( bind(socket_fd, (struct sockaddr*)&servaddr, sizeof(servaddr)) == -1)
    {  
        printf("bind socket error: %s(errno: %d)\n",strerror(errno),errno);  
        exit(0);  
    }  
    if( listen(socket_fd, 10) == -1)
    {  
        printf("listen socket error: %s(errno: %d)\n",strerror(errno),errno);  
        exit(0);  
    }  
    printf("======waiting for client's request======\n");    //main 
    while(1)
    {  
       printf("wait......\n");
        if( (connect_fd = accept(socket_fd, (struct sockaddr*)NULL, NULL)) == -1)
        {  
            printf("accept socket error: %s(errno: %d)",strerror(errno),errno);  
            continue;  
        } 
        printf("get a new cli\n"); 
        while(!fork())    //a new ser to a cli
        {
            int n=0;
            n = recv(connect_fd, buff, 4095, 0);  
            if(0==n)
                return 0;
            buff[n] = '\0';
            printf("recv msg from client: %s\n", buff);
            char login[]="login\n";   //login id
            char sign[]="sign\n";
            char quit[]="quit\n";
            char change[]="change name\n";
            char addfr[]="add a friend\n";
            char check[]="check file\n";
            char chat[]="i went to chat\n";
            char renew[]="renew data\n";
            char agree[]="agree friend\n";
            char seefriend[]="see friend\n";
            printf("%s",buff);
            if(strcmp(buff,seefriend)==0)
            {
                char seefi[20]={0};
                recv(connect_fd,seefi,20,0);
                seefr(connect_fd,seefi);
            }
            if(strcmp(buff,agree)==0)
            {
                char agreeid[4096]={0};
                recv(connect_fd,agreeid,20,0);
                agreefriend(agreeid);
                send(connect_fd,&nowuser,sizeof(user),0);
            } 
            if(strcmp(buff,renew)==0)
            {
                printf("i am renew my data!!!!!!!!!!!!!!!!!!\n");
    FILE *fp=fopen("./userset","a+");
    int number=0;
    fread(&number,4,1,fp);
    printf("user have %d\n",number);
    tail=&usenull;
    for(;number>0;number--)
    {
        int oldsize=0;
        fread(&oldsize,4,1,fp);
        user *olduser=(user *)malloc(oldsize);
        fread(olduser,oldsize,1,fp);
        olduser->next=NULL;
        tail->next=olduser;
        tail=tail->next;
    }
    fclose(fp);
    tail=&usenull;
    int idture=0;
    while(tail->next!=NULL)
    {
        tail=tail->next;
        if( strcmp(nowuser.id,tail->id)==0 )
        {
            idture++;
            break;
        }
    }
    printf("my friend number is %d\n",tail->friendnum);
    nowuser=*tail;
    freeuser();

                printf("my firend number have %d\n",nowuser.friendnum);   //
                send(connect_fd,&nowuser,sizeof(user),0);
                printf("i am renew data\n");
                printf("this id is %s",nowuser.id);
                int ren=strlen(nowuser.id);
                printf("id len is %di\n",ren);
                char renewuser[20]={0};
                strcpy(renewuser,nowuser.id);
                printf("cmp id id %s",renewuser);
                renewuser[ren-1]='\0';
                FILE *fl=fopen(renewuser,"a+");
                printf("i open the file %s!\n",renewuser);
                int renewstate;
                while(1)
                {
                    renewstate=0;
                    printf("i will read state\n");
                    fread(&renewstate,4,1,fl);
                    printf("i am read state is %d\n",renewstate);
                    if(renewstate==0)
                    {
                        send(connect_fd,"read over\n",20,0);
                        printf("read over\n");
                        break;
                    }
                    if(renewstate==1)
                    {
                        char success[20]={0};
                        send(connect_fd,"request news\n",20,0);
                        recv(connect_fd,success,20,0);
                        printf("%s",success);
                        printf("request news\n");
                        int renewsize;
                        fread(&renewstate,4,1,fl);
                        printf("len %d\n",renewstate);
                        char renewid[20]={0};
                        fread(&renewid,20,1,fl);
                        printf("read id is %s!\n",renewid);
                        send(connect_fd,renewid,20,0);
                    }
                    if(renewstate==3)
                    {
                        char renewid[20]={0};
                        fread(renewid,20,1,fl);
                        printf("i get new form %s !",renewid);
                        int renewsize;
                        fread(&renewsize,4,1,fl);
                        printf("renewsize=%d\n",renewsize);
                        char renewbuf[4096]={0};
                        fread(renewbuf,renewsize,1,fl);
                        printf("new is %s",renewbuf);
                        send(connect_fd,"chat news\n",20,0);
                        sleep(1);
                        send(connect_fd,renewid,20,0);
                        sleep(1);
                        send(connect_fd,&renewsize,4,0);
                        sleep(1);
                        send(connect_fd,renewbuf,renewsize,0);
                    }
                }
                fclose(fl);
                fl=fopen(renewuser,"w+");
                fclose(fl);
            }    
            if(strcmp(buff,chat)==0)
            {
                printf("user went to chat!\n");
                char chatname[20]={0};
                recv(connect_fd,chatname,20,0);
                printf("chatid is %s",chatname);
                int chatlen=strlen(chatname);
                chatname[chatlen-1]='\0';
                printf("file is %s!\n",chatname);
                FILE *fk=fopen(chatname,"a+");
                int chatstate=3;
                fwrite(&chatstate,4,1,fk);
                fwrite(nowuser.id,20,1,fk);
                char chatbuff[4096]={0};
                printf("s1\n");
                recv(connect_fd,chatbuff,4095,0);
                printf("s2\n");
                printf("new is %s\n",chatbuff);  
                int chatsize=0;
                chatsize=strlen(chatbuff)+1;
                
                fwrite(&chatsize,4,1,fk);
                fwrite(chatbuff,chatsize,1,fk);
                fclose(fk);
                printf("write over!\n");
            }
            if(strcmp(buff,check)==0)
            {
                int  newtype=0;
                char usfile[20];
                strcpy(usfile,nowuser.id);
                int usfilesize=strlen(usfile);
                usfile[usfilesize-1]='\0';
                printf("my file name is %s heihei\n",usfile);
                FILE *fj=fopen(usfile,"a+");
                while(1)
                {
                    sleep(1);
                    
                    newtype=0;
                    fread(&newtype,4,1,fj);
                    printf("i am read file state data %d\n",newtype);
                    if(newtype==0)
                    {
                        send(connect_fd,"system news read over\n",50,0);
                        fclose(fj);
                        break;
                    }
                    if(newtype==1)
                    {
                        char systemnew[4096]={0};
                        int  systemsize=0; 
                        fread(&systemsize,4,1,fj);   //requestor id size
                        fread(systemnew,systemsize,1,fj); //requertor id
                        int i4;   //check requertor have been now?
                        int i5=0;
                        for(i4=0;i4<nowuser.friendnum;i4++)
                        {
                            if(strcmp(nowuser.friend[i4][0],systemnew)==0)
                            {
                                i5++;
                                break;
                            }
                        }
                        if(i5>0)
                            continue;
                        send(connect_fd,"someone went to be your friend\n",50,0);
                        send(connect_fd,systemnew,4096,0);  
                        char n4[20]={0};
                        recv(connect_fd,n4,19,0);
                        if(strcmp(n4,"agree\n")==0)
                        {
                            agreefriend(systemnew);
                            printf("im new friend %s",nowuser.friend[nowuser.friendnum-1][0]);
                            printf("i have %d friend\n",nowuser.friendnum);
                            send(connect_fd,&nowuser,sizeof(user),0);
                            printf("send success\n");
                        }
                        
                        continue;
                    }
                }
                fj=fopen(usfile,"w+");
                close(fj);
            }    
            if(strcmp(buff,addfr)==0)
            {
                int n1=0;
                char addid[20]={0};
                recv(connect_fd,addid,19,0);
                printf("what is id?id is %s   su\n",addid);
                n1=addfriend(addid);
                if(n1==0)
                    send(connect_fd,"id not exist\n",50,0);
                if(n1==1)
                    send(connect_fd,"add friend request already sent\n",50,0);
            }
            if(strcmp(buff,change)==0)
            {
               int n1=0;
               char newname[20]={0};
               recv(connect_fd,newname,19,0);
               n1=changeuser(newname);
               if(n1==2)
                   send(connect_fd,"name change success\n",50,0);
               else
                   send(connect_fd,"name change error\n",50,0);
               sleep(1);
                   send(connect_fd,&nowuser,sizeof(user),0);
            }
            if(strcmp(buff,login)==0)
            {
                int n1;
                char newid[2][20]={0};
                recv(connect_fd, newid,40,0);
                n1=adduser(newid);
                if(n1==0)
                    send(connect_fd,"id has been registered\n",50,0);
                if(n1==1)
                    send(connect_fd,"id registration successful\n",50,0);
                continue;
            }
            if(strcmp(buff,sign)==0)
            {
                int n2;
                char newid[2][20]={0};
                recv(connect_fd,newid,40,0);
                n2=signset(newid);
                if(n2==0)
                    send(connect_fd,"id does not exist\n",50,0);
                if(n2==1)
                {
                    send(connect_fd,"lognin successful\n",50,0);
                    sleep(1);
                    send(connect_fd,&nowuser,sizeof(user),0);
                }
                if(n2==2)
                    send(connect_fd,"node is error\n",50,0);
                continue;
             }
            if(strcmp(buff,quit)==0)
            {
                if(send(connect_fd, "quit success\n", 26,0) == -1)
                    printf("error\n");
                quituser();
                close(connect_fd);
                return 0;
            } 
        }
        signal(SIGCHLD,killchild); 
        close(connect_fd);  
    }  
    close(socket_fd);  
}  
