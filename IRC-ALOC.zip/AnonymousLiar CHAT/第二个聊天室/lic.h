int face1(char a[2][20] )
{
    while(1)
    {
        system("clear");
        printf("----welcome to use SU chat room----\n");
        printf("If you already have an account,press 1\n");
        printf("If you do not  have an accout,press 2 to register\n");
        printf("Enter(1 or 2):");
        char num[5];
        fgets((char *)&num,5,stdin);
        if( strcmp(num,"1\n")==0)
        {
            printf("Please enter id:");
            fgets(a[0],20,stdin);
            printf("Please enter codes:");
            fgets(a[1],20,stdin);
            return 0;
        }
        if( strcmp(num,"2\n")==0 )
        {
            printf("Please enter id:");
            fgets(a[0],20,stdin);
            printf("Please enter codes:");
            fgets(a[1],20,stdin);
            return 1;
        }
     }
}
int face2()
{
    while(1)
    {
        char n[5]={0};
        system("clear");
        printf("------Hello %s\n",myuser.name);
        printf("1:Change name\n");
        printf("2:qiut\n");
        printf("3:see friend\n");
        printf("4:add frined\n");
        printf("5:seach system news\n");
        printf("6:chat friend\n");
        printf("pleace enter number:");
        fgets(n,3,stdin);
        if(strcmp(n,"1\n")==0)
            return 1;
        if(strcmp(n,"2\n")==0)
            return 2;
        if(strcmp(n,"3\n")==0)
            return 3;    
        if(strcmp(n,"4\n")==0)
            return 4;    
        if(strcmp(n,"5\n")==0)
            return 5;
        if(strcmp(n,"6\n")==0)
            return 6;
    }
}    
void creatfile()
{
     char myname[20]={0};
     strcpy(myname,myuser.id);
     int n=strlen(myname);
     myname[n-1]='\0';
     FILE *fd=fopen(myname,"a+");
     fclose(fd);
     int n1;
     for(n1=0;n1<myuser.friendnum;n1++)
     {
         char friendname[40]={0};
         strcpy(friendname,myuser.friend[n1][0]);
         n=strlen(friendname);
         friendname[n-1]='\0';
         printf("%s,,,,,%s\n",friendname,myname);
         strcat(friendname,myname);
         fd=fopen(friendname,"a+");
         fclose(fd);
     }
     printf("over\n");
}
int renew(int sockfd)
{
    send(sockfd,"renew data\n",20,0);
    recv(sockfd,&myuser,sizeof(user),0);
    while(1)
    {
        char renewstate[40]={0};
        recv(sockfd,renewstate,20,0);
        send(sockfd,"send success\n",20,0);
        if(strcmp(renewstate,"read over\n")==0)
            return 0;
        if(strcmp(renewstate,"request news\n")==0)
        {
            int n7=1;
            char renewid[20]={0};
            recv(sockfd,renewid,20,0);
            int renewsize=0;
            renewsize=strlen(myuser.id);
            char renewsys[20]={0};
            strcpy(renewsys,myuser.id);
            renewsys[renewsize-1]='\0';
            FILE *fq=fopen(renewsys,"a+");
            fwrite(&n7,4,1,fq);
            n7=20;
            fwrite(&n7,4,1,fq);
            fwrite(renewid,20,1,fq);
            fclose(fq);
        }
        if(strcmp(renewstate,"chat news\n")==0)
        {
            int renewsize;
            char renewid[20]={0};
            int renewbuff[4096]={0};
            recv(sockfd,renewid,20,0);
            recv(sockfd,&renewsize,4,0);
            recv(sockfd,renewbuff,renewsize,0);
            char renewfile[40]={0};
            strcpy(renewfile,renewid);
            int n9=strlen(renewfile);
            renewfile[n9-1]='\0';
            strcat(renewfile,myuser.id);
            n9=strlen(renewfile);
            renewfile[n9-1]='\0';
            FILE *fw=fopen(renewfile,"a+");
            fwrite(renewid,20,1,fw);
            fwrite(&renewsize,4,1,fw);
            fwrite(renewbuff,renewsize,1,fw);
            fclose(fw);
        }
    }   
    getchar(); 
}
void clearroom()
{
    int i=0;
    printf("\033[0m\033[1;1H");
    for(i=0;i<25;i++)
    {
      printf("\033[0m\033[K");
      printf("\n");
    }
    printf("kkk12adsasdfq3r12adkfaefawrawreakwr\n");
}
void chatnew()
{
    if(alarmstate!=1)
    {
        printf("\n");
    }
    else if(chat_wjb==1)
    {
        alarm(3);
    }
    else
    {
    printf("\033[0m\033[s");
    printf("\033[0m\033[1;1H");
    char chatid[20]={0};
    int sockfd=sockfd_wjb;
    strcpy(chatid,chatid_wjb);
    renew(sockfd);
    int i=0;
    printf("\033[0m\033[1;1H");
    for(i=0;i<25;i++)
    {
      printf("\033[0m\033[K");
      printf("\n");
    }
    printf("\033[0m\033[1;1H");
    printf("------chat room--------\n");
    char chatnewid[20]={0};
    strcpy(chatnewid,chatid);
    chatnewid[strlen(chatnewid)-1]='\0';
    strcat(chatnewid,myuser.id);
    chatnewid[strlen(chatnewid)-1]='\0';
    int newnum=0;
    FILE *fr=fopen(chatnewid,"a+");
    while(1)
    {
        int n8;
        char systemid[20]={0};
        n8=0;
        n8=fread(systemid,20,1,fr);
        if(n8==0)
            break;
        char chatbuff[4096]={0};
        fread(&n8,4,1,fr);
        fread(chatbuff,n8,1,fr);
        newnum++;
    }
    fclose(fr);
    fr=fopen(chatnewid,"a+");
    while(1)
    {
        int n8;
        char systemid[20]={0};
        n8=0;
        n8=fread(systemid,20,1,fr);
        if(n8==0)
            break;
        char chatbuff[4096]={0};
        fread(&n8,4,1,fr);
        fread(chatbuff,n8,1,fr);
        if(newnum>7)
        {
             newnum--;
             continue;
        }
        if(strcmp(systemid,chatid)==0)
            printf("friend:%s\n",chatbuff);
        else
            printf("me:%s\n",chatbuff);
     }
     fclose(fr);
     printf("\033[0m\033[u");
     fflush(stdout);
     if(alarmstate==1)
         alarm(2);
     }
}
int chatroom(int sockfd,char chatid[20])
{
    alarmstate=1;
    chat_wjb=0;
    char buff[4096]={0};
    system("clear");
    alarm(2);
    signal(SIGALRM,chatnew);
    while(1)
    {
        printf("\033[0m\033[30;1H");
        printf("\n-------chat %s",chatid);
        char chat[20]="i went to chat\n";
        sleep(1);
        printf("Enter news:");
        fgets(buff,4095,stdin);  //buff
        chat_wjb=1;
        send(sockfd,chat,20,0);  
        sleep(1);
        send(sockfd,chatid,20,0);
        time_t timep;  
        time(&timep);
        char sendname[4095]={0};
        strcpy(sendname,myuser.id);
        send(sockfd,chat,strlen(chat),0);
        sendname[strlen(sendname)-1]=':';
        buff[strlen(buff)-1]='\0';
        strcat(sendname,buff);
        strcpy(buff,sendname);   
        char timesend[]={"     send time:"};
        strcat(buff,timesend);
        strcat(buff,ctime(&timep));
        send(sockfd,buff,strlen(buff),0); 
        chat_wjb=0;
        char chatnewid[20]={0}; 
        strcpy(chatnewid,chatid);
        chatnewid[strlen(chatnewid)-1]='\0';
        strcat(chatnewid,myuser.id);
        chatnewid[strlen(chatnewid)-1]='\0';
        FILE *fr=fopen(chatnewid,"a+");
        fwrite(myuser.id,20,1,fr);
        int sizebuff=strlen(buff);;
        fwrite(&sizebuff,4,1,fr);
        fwrite(buff,sizebuff,1,fr);
        fclose(fr);
        while(1)
        {
            printf("1:quit\n");
            printf("2:continue chat\n");
            printf("Enter:");
            char chatstate[5]={0};
            fgets(chatstate,3,stdin);
            if(strcmp(chatstate,"1\n")==0)
            {
                alarmstate=0;
                return 0;
            }
            if(strcmp(chatstate,"2\n")==0)
                break;
        }
        system("clear");
    }
    return 0;
} 
void seefriend(int sockfd)
{
    int i;
    renew(sockfd);
    printf("-------your friend link--------\n");
    for(i=0;i<myuser.friendnum;i++)
    {
        printf("id %s\n",myuser.friend[i][0]);
        printf("name %s\n",myuser.friend[i][1]);
        int state;
        send(sockfd,"see friend\n",20,0);
        sleep(1);
        send(sockfd,myuser.friend[i][0],20,0);
        recv(sockfd,&state,4,0);
        if(state==0)
            printf("off line\n");
        if(state==1)
            printf("on line\n");
        printf("------------------------\n");
    }
    getchar();
}