#include<stdio.h>  
#include<stdlib.h>  
#include<string.h>  
#include<errno.h>  
#include<sys/types.h>  
#include<sys/socket.h>  
#include<netinet/in.h>
#include <time.h>  
#include<signal.h>
#include<unistd.h>
typedef struct userinfo
{
    char id[20];
    char codes[20];
    char name[20];
    struct userinfo *next;
    int friendnum;
    int state;
    char friend[100][2][20];
}user;
user myuser;
int sockfd_wjb;
int chat_wjb;
char chatid_wjb[20]={0};
int alarmstate;
#include"lic.h" 
int main(int argc, char** argv)  
{  
    int    sockfd, n,rec_len;  
    char    recvline[4096], sendline[4096];  
    char    buf[4095];  
    struct sockaddr_in servaddr;   
    if( argc != 2)
    {  
        printf("usage: ./client <ipaddress>\n");  
        exit(0);  
    }  
    if( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {  
        printf("create socket error: %s(errno: %d)\n", strerror(errno),errno);  
        exit(0);  
    }  
    memset(&servaddr, 0, sizeof(servaddr));  
    servaddr.sin_family = AF_INET;  
    servaddr.sin_port = htons(8000);  
    if( inet_pton(AF_INET, argv[1], &servaddr.sin_addr) <= 0)
    {  
        printf("inet_pton error for %s\n",argv[1]);  
        exit(0);  
    }  
    if( connect(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr)) < 0)
    {  
        printf("connect error: %s(errno: %d)\n",strerror(errno),errno);  
        exit(0);  
    } 
    char a[2][20];
    while(1)
    {
        int b=face1(a);
        if(b==1)
        {
            char login[]="login\n";
            char num[4096]={0};
            send(sockfd,login,strlen(login),0);
            send(sockfd,a,sizeof(a),0);
            recv(sockfd,num,4095,0);
            printf("get:%s",num);
            getchar();
            if(strcmp(num,"id has been registered\n")==0)
                continue;
            if(strcmp(num,"id registration successful\n")==0)
                continue;
         }
         if(b==0)
         {
             char sign[]="sign\n";
             char num[4096]={0};
             send(sockfd,sign,strlen(sign),0);
             send(sockfd,a,sizeof(a),0);
             recv(sockfd,num,4095,0);
             printf("get:%s",num);
             getchar();
             if( strcmp(num,"id does not exist\n")==0 )
                 continue;
             if( strcmp(num,"node is error\n") ==0 )
                 continue;
             if( strcmp(num,"lognin successful\n")==0 )
                 break;      
          }
    }
    printf("1\n");
    recv(sockfd,&myuser,4095,0);
    printf("2\n");
    creatfile();
    printf("3\n");
    renew(sockfd);
    printf("4\n");
    while(1)
    {   
        int sele=face2();
        if(sele==6)
        {
            while(1)
            {
                 printf("please enter you went chat friend id\n");
                 printf("Enter:");
                 char chatid[20]={0};
                 fgets(chatid,20,stdin);
                 int i5=0;
                 int i5a=0;
                 for(i5=0;i5<myuser.friendnum;i5++)
                 {
                      if(strcmp(chatid,myuser.friend[i5][0])==0)
                      {
                           i5a++;
                           break;
                      }
                 }
                 if(i5a==0)
                 {
                      char n6[5]={0};
                      while(1)
                      {
                          printf("this id not your friend!\n");
                          printf("1:return main inteface\n");
                          printf("2:continue\n");
                          printf("enter:");
                          fgets(n6,3,stdin);
                          if(strcmp(n6,"1\n")==0)
                              break;
                          if(strcmp(n6,"2\n")==0)
                              break;
                      }
                      if(strcmp(n6,"1\n")==0)
                          break;
                      if(strcmp(n6,"2\n")==0)
                          continue;
                 }
                 if(i5a!=0)
                 {
                     printf("shi is you friend\n"); 
                     sockfd_wjb=sockfd;
                     strcpy(chatid_wjb,chatid);
                     chatroom(sockfd,chatid);
                     printf("chat over!");
                     getchar();
                     break;
                 }
            }
        }
        if(sele==2)
        {
            strcpy(sendline,"quit\n");
            if( send(sockfd, sendline, strlen(sendline), 0) < 0)  
            {  
                printf("send msg error: %s(errno: %d)\n", strerror(errno), errno);  
                exit(0);  
            }  
            sleep(1);
            if((rec_len = recv(sockfd, buf, 4095,0)) == -1) 
            {  
                perror("recv error");  
                exit(1);  
            }  
            buf[rec_len]  = '\0';  
            printf("get: %s ",buf);
            char quit[]="quit success\n";
            if(strcmp(buf,quit)==0)
            break;
        }
        if(sele==1)
        {
            strcpy(sendline,"change name\n");
            if( send(sockfd, sendline, strlen(sendline), 0) < 0)  
            {  
                printf("send msg error: %s(errno: %d)\n", strerror(errno), errno);  
                exit(0);  
            }  
            printf("enter you went name:");
            char newname[20];
            fgets(newname,20,stdin);
            if( send(sockfd, newname, strlen(newname), 0) < 0)  
            {  
                printf("send msg error: %s(errno: %d)\n", strerror(errno), errno);  
                exit(0);  
            }  
            if((rec_len = recv(sockfd, buf, 4095,0)) == -1) 
            {  
                perror("recv error");  
                exit(1);  
            }  
            buf[rec_len]  = '\0';  
            printf("get:%s",buf); 
            recv(sockfd,&myuser,4095,0);
            getchar();
        }
        if(sele==3)
            seefriend(sockfd);
        if(sele==4)
        {
            strcpy(sendline,"add a friend\n");
            char addid[20]={0};
            printf("please enter you went add id:");
            fgets(addid,19,stdin);
            int adda;
            int addab=0;
            for(adda;adda<myuser.friendnum;adda++)
            {
                if( strcmp(myuser.friend[adda][0],addid)==0 )
                {
                    printf("he has been you friend,not add\n");
                    addab=1;
                    break;
                }
            }
            if(addab==1)
                continue;
            if( send(sockfd, sendline, strlen(sendline), 0) < 0)  
            {  
                printf("send msg error: %s(errno: %d)\n", strerror(errno), errno);  
                exit(0);  
            }  
            if( send(sockfd, addid, strlen(addid), 0) < 0)  
            {  
                printf("send msg error: %s(errno: %d)\n", strerror(errno), errno);  
                exit(0);  
            }  
            if((rec_len = recv(sockfd, buf, 4095,0)) == -1) 
            {  
                perror("recv error");  
                exit(1);  
            }  
            buf[rec_len]  = '\0';  
            printf("get:%s",buf);
            getchar();
        } 
        if(sele==5)
        {
            renew(sockfd);
            char systemid[20]={0};
            int systemlen=strlen(myuser.id);
            strcpy(systemid,myuser.id);
            systemid[systemlen-1]='\0';
            FILE *fe=fopen(systemid,"a+");
            while(1)
            {
                int systemstate;
                systemstate=0;
                fread(&systemstate,4,1,fe);
                if(systemstate==0)
                    break;
                if(systemstate==1)
                {
                    int systemsize=0;
                    char systemid[20]={0};
                    fread(&systemsize,4,1,fe);
                    fread(systemid,20,1,fe);
                    while(1)
                    {
                        char agre[5]={0};
                        printf("shi went quester be your frienid:%s",systemid);
                        printf("agree to press 1\n");
                        printf("refuse to press 2\n");
                        fgets(agre,3,stdin);
                        if(strcmp(agre,"1\n")==0)
                        { 
                            send(sockfd,"agree friend\n",20,0);
                            sleep(1);
                            send(sockfd,systemid,20,0);
                            recv(sockfd,&myuser,4096,0);
                            break;
                        }
                        if(strcmp(agre,"2\n")==0)
                            break;
                    }
                }
            }
            fclose(fe);               
            fe=fopen(systemid,"w+");
            fclose(fe);               
        }      
    }
} 