void killchild()
{
    while(waitpid(-1,NULL,WNOHANG));
}
void seach()
{
    tail=&usenull;
    while(tail->next!=NULL)
    {
        tail=tail->next;
        printf("id=%s\n",tail->id);
    }
}
void freeuser()
{
    head=&usenull;
    tail=head->next;
    while(head->next!=NULL)
    {
        while(tail->next=NULL)
        {
            tail=tail->next;
            head=head->next;
        }
        free(tail);
        head->next=NULL;
        head=&usenull;
        tail=head->next;
    }
}
int seefr(int connect_fd,char seefi[20])
{
    FILE *fp=fopen("./userset","a+");
    int number=0;
    fread(&number,4,1,fp);
    printf("user have %d\n",number);
    tail=&usenull;
    for(;number>0;number--)
    {
        int oldsize=0;
        fread(&oldsize,4,1,fp);
        user *olduser=(user *)malloc(oldsize);
        fread(olduser,oldsize,1,fp);
        printf("i am read a user,name is %s\n",olduser->id);
        olduser->next=NULL;
        tail->next=olduser;
        tail=tail->next;
    }
    fclose(fp);
    tail=&usenull;
    int idture=0;
    while(tail->next!=NULL)
    {
        tail=tail->next;
        if( strcmp(seefi,tail->id)==0 )
        {
            idture++;
            break;
        }
    }
    send(connect_fd,&(tail->state),4,0);
    freeuser();
    return 0;
}
int quituser()
{
    printf("i will quit\n");
    FILE *fp=fopen("./userset","a+");
    int number=0;
    fread(&number,4,1,fp);
    printf("user have %d\n",number);
    tail=&usenull;
    for(;number>0;number--)
    {
        int oldsize=0;
        fread(&oldsize,4,1,fp);
        user *olduser=(user *)malloc(oldsize);
        fread(olduser,oldsize,1,fp);
        printf("i am read a user,name is %s\n",olduser->id);
        olduser->next=NULL;
        tail->next=olduser;
        tail=tail->next;
    }
    fclose(fp);
    tail=&usenull;
    int idture=0;
    while(tail->next!=NULL)
    {
        tail=tail->next;
        if( strcmp(nowuser.id,tail->id)==0 )
        {
            idture++;
            break;
        }
    }
    tail->state=0;
    FILE *fd=fopen("./userset","w+");   //write new data
    int newnumber=0;
    tail=&usenull;
    while(tail->next!=NULL)
    {
        newnumber++;
        tail=tail->next;
    }
    printf("new user have %d\n",newnumber);
    fwrite(&newnumber,4,1,fd);
    tail=&usenull;
    tail=tail->next;
    while(tail!=NULL)
    {
        int newsize=sizeof(user);
        fwrite(&newsize,4,1,fd);
        printf("id %s have write file\n",tail->id);
        printf("state is %d\n",tail->state);
        fwrite(tail,newsize,1,fd);
        tail=tail->next;
    }
    fclose(fd);
    freeuser();
}
int renewuser()
{
    printf("i am renew my data!!!!!!!!!!!!!!!!!!\n");
    FILE *fp=fopen("./userset","a+");
    int number=0;
    fread(&number,4,1,fp);
    printf("user have %d\n",number);
    tail=&usenull;
    for(;number>0;number--)
    {
        int oldsize=0;
        fread(&oldsize,4,1,fp);
        user *olduser=(user *)malloc(oldsize);
        fread(olduser,oldsize,1,fp);
        olduser->next=NULL;
        tail->next=olduser;
        tail=tail->next;
    }
    fclose(fp);
    tail=&usenull;
    int idture=0;
    while(tail->next!=NULL)
    {
        tail=tail->next;
        if( strcmp(nowuser.id,tail->id)==0 )
        {
            idture++;
            break;
        }
    }
    printf("my friend number is %d\n",tail->friendnum);
    nowuser=*tail;
    freeuser();
    return 0;
}

int adduser(char a[2][20])
{
    FILE *fp=fopen("./userset","a+");
    int number=0;
    fread(&number,4,1,fp);
    printf("user have %d\n",number);
    tail=&usenull;
    for(;number>0;number--)
    {
        int oldsize=0;
        fread(&oldsize,4,1,fp);
        user *olduser=(user *)malloc(oldsize);
        fread(olduser,oldsize,1,fp);
        printf("i am read a user,name is %s\n",olduser->id);
        olduser->next=NULL;
        tail->next=olduser;
        tail=tail->next;
    }
    fclose(fp);
    tail=&usenull;
    while(tail->next!=NULL)
    {
        tail=tail->next;
        if( strcmp(a[0],tail->id)==0 )
        {
            printf("this id has been\n");
            return 0;
        }
    }
    printf("this id is  not find\n");
    user *newuser=(user *)malloc(sizeof(user));   //init user
    strcpy(newuser->id,a[0]);
    strcpy(newuser->codes,a[1]);
    strcpy(newuser->name,a[0]);
    newuser->next=NULL;
    newuser->friendnum=0;
    newuser->state=0;
    tail->next=newuser;
    printf("filename is %s",a[0]);
    int cao=strlen(a[0]);
    a[0][cao-1]='\0';
    int asd=creat(a[0],666);         //creat myself file
    close(asd);
    FILE *fg=fopen(a[0],"w+");
    fclose(fg);
    printf("creat file successs\n"); 
    FILE *fd=fopen("./userset","w+");   //write new data
    int newnumber=0;
    tail=&usenull;
    while(tail->next!=NULL)
    {
        newnumber++;
        tail=tail->next;
    }
    printf("new user have %d\n",newnumber);
    fwrite(&newnumber,4,1,fd);
    tail=&usenull;
    tail=tail->next;
    while(tail!=NULL)
    {
        int newsize=sizeof(user);
        fwrite(&newsize,4,1,fd);
        printf("id %s have write file\n",tail->id);
        fwrite(tail,newsize,1,fd);
        tail=tail->next;
    }
    fclose(fd);
    freeuser();
    return 1;
}
int signset(char a[2][20])
{
    FILE *fp=fopen("./userset","a+");
    int number=0;
    fread(&number,4,1,fp);
    printf("user have %d\n",number);
    tail=&usenull;
    for(;number>0;number--)
    {
        int oldsize=0;
        fread(&oldsize,4,1,fp);
        user *olduser=(user *)malloc(oldsize);
        fread(olduser,oldsize,1,fp);
        printf("i am read a user,name is %s\n",olduser->id);
        olduser->next=NULL;
        tail->next=olduser;
        tail=tail->next;
    }
    fclose(fp); 
    tail=&usenull;
    int idture=0;
    while(tail->next!=NULL)
    {
        tail=tail->next;
        if( strcmp(a[0],tail->id)==0 )
        {
            idture++;
            break;
        }
    }
    if(idture==0)
    {
        freeuser();
        return 0;
    }
    if(strcmp(a[1],tail->codes)==0)    //sign success
    {
        tail->state=1;
        nowuser=*tail;
        FILE *fd=fopen("./userset","w+");   //write new data
        int newnumber=0;
        tail=&usenull;
        while(tail->next!=NULL)
        {
            newnumber++;
            tail=tail->next;
        }
        printf("new user have %d\n",newnumber);
        fwrite(&newnumber,4,1,fd);
        tail=&usenull;
        tail=tail->next;
        while(tail!=NULL)
        {
            int newsize=sizeof(user);
            fwrite(&newsize,4,1,fd);
            printf("id %s have write file\n",tail->id);
            fwrite(tail,newsize,1,fd);
            tail=tail->next;
        }
        fclose(fd);
        freeuser();
        return 1;
    }
    freeuser();
    return 2;
}
int changeuser( char newname[20])
{
    FILE *fp=fopen("./userset","a+");
    int number=0;
    fread(&number,4,1,fp);
    printf("user have %d\n",number);
    tail=&usenull;
    for(;number>0;number--)
    {
        int oldsize=0;
        fread(&oldsize,4,1,fp);
        user *olduser=(user *)malloc(oldsize);
        fread(olduser,oldsize,1,fp);
        printf("i am read a user,name is %s\n",olduser->id);
        olduser->next=NULL;
        tail->next=olduser;
        tail=tail->next;
    }
    fclose(fp);
    tail=&usenull;
    while(tail->next!=NULL)
    {
        tail=tail->next;
        if( strcmp(nowuser.id,tail->id)==0 )
        {
            printf("this id has been\n");
            break;
        }
    }
    strcpy(tail->name,newname);
    nowuser=*tail;
    FILE *fd=fopen("./userset","w+");
    int newnumber=0;
    tail=&usenull;
    while(tail->next!=NULL)
    {
        newnumber++;
        tail=tail->next;
    }
    printf("new user have %d\n",newnumber);
    fwrite(&newnumber,4,1,fd);
    tail=&usenull;
    tail=tail->next;
    while(tail!=NULL)
    {
        int newsize=sizeof(user);
        fwrite(&newsize,4,1,fd);
        printf("id %s have write file\n",tail->id);
        fwrite(tail,newsize,1,fd);
        tail=tail->next;
    }
    fclose(fd);
    freeuser(); 
    return 2;
}
int addfriend(char a[20])
{
    FILE *fp=fopen("./userset","a+");   //is there a judgment?
    int number=0;
    fread(&number,4,1,fp);
    printf("user have %d\n",number);
    tail=&usenull;
    for(;number>0;number--)
    {
        int oldsize=0;
        fread(&oldsize,4,1,fp);
        user *olduser=(user *)malloc(oldsize);
        fread(olduser,oldsize,1,fp);
        printf("i am read a user,name is %s\n",olduser->id);
        olduser->next=NULL;
        tail->next=olduser;
        tail=tail->next;
    }
    fclose(fp);
    tail=&usenull;
    int addtree=0;
    while(tail->next!=NULL)
    {
        tail=tail->next;
        if( strcmp(a,tail->id)==0 )
        {
            printf("this id has been\n");
            addtree++;       //judgment
            break;
        }
    }
    if(addtree==0)
       return 0;     //id id not judgment
    char adf[20];
    strcpy(adf,tail->id);
    int adfsize=strlen(adf);
    adf[adfsize-1]='\0';
    freeuser();
    printf("open file name is %s\n",adf);
    FILE *fh=fopen(adf,"a+");
    int newsstate=1;
    fwrite(&newsstate,4,1,fh);
    int newssize=20;
    fwrite(&newssize,4,1,fh);
    fwrite(nowuser.id,newssize,1,fh);
    fclose(fh);
    return 1;
}
int agreefriend(char systemnew[4096])
{
    FILE *fp=fopen("./userset","a+");   //see you are there?
    int number=0;
    fread(&number,4,1,fp);
    printf("user have %d\n",number);
    tail=&usenull;
    for(;number>0;number--)
    {
        int oldsize=0;
        fread(&oldsize,4,1,fp);
        user *olduser=(user *)malloc(oldsize);
        fread(olduser,oldsize,1,fp);
        printf("i am read a user,name is %s\n",olduser->id);
        olduser->next=NULL;
        tail->next=olduser;
        tail=tail->next;
    }
    fclose(fp);
    tail=&usenull;
    while(tail->next!=NULL)
    {
        tail=tail->next;
        if( strcmp(systemnew,tail->id)==0 )
        {
            printf("on i find he,i agree withe you be friend\n");
            break;
        }
    }
    nowuser.friendnum+=1;  //friend+1;
    strcpy(nowuser.friend[nowuser.friendnum-1][0],tail->id);
    strcpy(nowuser.friend[nowuser.friendnum-1][1],tail->name);
    tail->friendnum+=1;
    strcpy(tail->friend[tail->friendnum-1][0],nowuser.id);
    strcpy(tail->friend[tail->friendnum-1][1],nowuser.name);
    tail=&usenull;
    while(tail->next!=NULL)
    {
        tail=tail->next;
        if( strcmp(nowuser.id,tail->id)==0 )
        {
            printf("i find myself in file\n");
            break;
        }
    }
    nowuser.next=tail->next;
    *tail=nowuser;
    /*  i will updata to file*/
    FILE *fd=fopen("./userset","w+");   //write new data
    int newnumber=0;
    tail=&usenull;
    while(tail->next!=NULL)
    {
        newnumber++;
        tail=tail->next;
    }
    printf("new user have %d\n",newnumber);
    fwrite(&newnumber,4,1,fd);
    tail=&usenull;
    tail=tail->next;
    while(tail!=NULL)
    {
        int newsize=sizeof(user);
        fwrite(&newsize,4,1,fd);
        printf("id %s have write file\n",tail->id);
        fwrite(tail,newsize,1,fd);
        tail=tail->next;
    }
    fclose(fd);
    freeuser();
    return 0;
}